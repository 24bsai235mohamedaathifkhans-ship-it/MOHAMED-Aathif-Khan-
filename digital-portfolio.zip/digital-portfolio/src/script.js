// fill footer year
document.getElementById('year').textContent = new Date().getFullYear();

// project "open" demo handler (placeholder)
function openProject(name){
  alert('Open project: ' + name + '\n(This is a demo placeholder — replace with links to your projects.)');
}

// send button behaviour
document.getElementById('sendBtn').addEventListener('click', function(){
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const message = document.getElementById('message').value.trim();

  // Simple validation
  if(!name && !email && !phone && !message){
    alert('Please enter at least one contact detail or message before sending.');
    return;
  }

  // For CodePen/demo: just show confirmation and clear message
  alert('Thank you — message sent!\n\nNAME: ' + name + '\nEMAIL: ' + email + '\nPHONE: ' + phone);

  // Clear message box (keep name/email/phone as requested)
  document.getElementById('message').value = '';
});